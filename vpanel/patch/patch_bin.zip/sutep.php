<?php
//$kon1=mysql_connect("103.224.64.82","root","el1n");
$kon1=mysql_connect("192.168.99.99","root","el1n");
mysql_select_db("ujian70",$kon1);
?>