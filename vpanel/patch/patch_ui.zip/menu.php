<div class="left_nav_dash">
                <a href="./">
                    <div class="menu_left">
                        <span><img src="asset/img/home.png"></span> &nbsp Beranda
                    </div>
                </a>
                <!--<a>
                    <div class="menu_left">
                        <span><img src="asset/img/down.png"></span> &nbsp Status Download
                    </div>
                </a>-->
                <a href="daftarpeserta.php">
                    <div class="menu_left">
                        <span><img src="asset/img/status.png"></span> &nbsp Daftar Peserta
                    </div>
                </a>
                <a href="statustest.php">
                    <div class="menu_left">
                        <span><img src="asset/img/edit.png"></span> &nbsp Status Test
                    </div>
                </a>
                <a href="statuspeserta.php">
                    <div class="menu_left">
                        <span><img src="asset/img/user.png"></span> &nbsp Status Peserta
                    </div>
                </a>
                <a href="resetlogin.php">
                    <div class="menu_left">
                        <span><img src="asset/img/reset.png"></span> &nbsp Reset Login Peserta
                    </div>
                </a>
                <a href="cetakpresensi.php">
                    <div class="menu_left">
                        <span><img src="asset/img/settings.png"></span> &nbsp Cetak Presensi
                    </div>
                </a>
                <a href="logout.php">
                    <div class="menu_left">
                        <span><img src="asset/img/exit.png" style="transform:rotate(180deg);"></span> &nbsp Log Out
                    </div>
                </a>
            </div>