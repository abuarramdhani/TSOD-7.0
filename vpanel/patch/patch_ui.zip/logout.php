<?php
	require "../bin/setup.php";
	//echo "UPDATE login SET login='', mulai='', link='', ip='' WHERE user_id='$_SESSION[user_id]'"; exit;
	mysql_query("UPDATE login SET login='', link='', ip='' WHERE user_id='$_SESSION[user_id]'");
	$sesi=$_SESSION[user_agent];
	session_destroy();	
	header("Location: ./login.php");
	exit;
?>