<?php
	$filter=$converter->decode($_GET[filter]);
	$value=$converter->decode($_GET[value]);
?>
<div class="box">
	<div class="box-header">
<img src="./assets/view.result.png" width="48"> Hasil Ujian</div>
  
	<!-- /.box-header -->
	<div class="box-body">
		<table id="example1" class="table table-bordered table-striped">
			<thead>
				<tr>
					<th width="20">No.</th>
					<th width="60">Action</th>
					<th width="80">Id</th>
					<th>Nama Lengkap</th>
					<th width="40">Kelas</th>
					<th width="200">Ujian</th>
					<th width="40">Benar</th>
					<th width="40">Soal</th>
					<th width="40">Nilai</th>
					<th width="80">Waktu</th>
					<th >Lama Pengerjaan</th>					
				</tr>
			</thead>
			<tbody>
<?php   
		if ($_SESSION['is_admin'])
		{
			switch ($filter)  
			{
				case "kelas" : 					
					$qry="SELECT users.username, users.real_name, kelas.nm_kelas, ujian.nm_ujian, hasil.benar, hasil.soal, hasil.nilai, hasil.tgl_test, hasil.kd_hasil, users.user_id, hasil.tgl_selesai-hasil.tgl_test as selisih, users.user_id FROM hasil, users, ujian, kelas WHERE  hasil.user_id=users.user_id and ujian.kd_ujian=hasil.kd_ujian and kelas.kd_kelas=users.kd_kelas and users.kd_kelas='$value' "; //and hasil.status=10 ";
					break;
				case "mapel" : 					
					$qry="SELECT users.username, users.real_name, kelas.nm_kelas, ujian.nm_ujian, hasil.benar, hasil.soal, hasil.nilai, hasil.tgl_test, hasil.kd_hasil, users.user_id, hasil.tgl_selesai-hasil.tgl_test as selisih, users.user_id FROM hasil, users, ujian, kelas WHERE  hasil.user_id=users.user_id and ujian.kd_ujian=hasil.kd_ujian and kelas.kd_kelas=users.kd_kelas and ujian.kd_ujian='$value' ";//and hasil.status=10 ";
					break;
				case "modul" : 					
					$qry="SELECT users.username, users.real_name, kelas.nm_kelas, ujian.nm_ujian, hasil.benar, hasil.soal, hasil.nilai, hasil.tgl_test, hasil.kd_hasil, users.user_id, hasil.tgl_selesai-hasil.tgl_test as selisih, users.user_id FROM hasil, users, ujian, kelas, modul WHERE modul.kd_modul=ujian.kd_modul and hasil.user_id=users.user_id and ujian.kd_ujian=hasil.kd_ujian and kelas.kd_kelas=users.kd_kelas and ujian.kd_modul='$value' ";//and hasil.status=10 ";
					break;
				case "periode" : 
					$patokan1=$a[3]." 00:00:00";
					$patokan2=$a[4]." 23:59:59";					
					$qry="SELECT users.username, users.real_name, kelas.nm_kelas, ujian.nm_ujian, hasil.benar, hasil.soal, hasil.nilai, hasil.tgl_test, hasil.kd_hasil, users.user_id, hasil.tgl_selesai, hasil.tgl_selesai-hasil.tgl_test as selisih, users.user_id FROM hasil, users, ujian, kelas WHERE  hasil.user_id=users.user_id and ujian.kd_ujian=hasil.kd_ujian and kelas.kd_kelas=users.kd_kelas and hasil.tgl_test < '$patokan2' and hasil.tgl_test > '$patokan1' ";//and hasil.status=10 ";
					break;
				default : 					
					$qry="SELECT users.username, users.real_name, kelas.nm_kelas, ujian.nm_ujian, hasil.benar, hasil.soal, hasil.nilai, hasil.tgl_test, hasil.kd_hasil, users.user_id, hasil.tgl_selesai-hasil.tgl_test as selisih, users.user_id FROM users right join hasil on users.user_id=hasil.user_id left join ujian on ujian.kd_ujian=hasil.kd_ujian left join kelas on kelas.kd_kelas=users.kd_kelas";// and hasil.status=10 ";
					//$qry="SELECT * FROM hasil LEFT JOIN users ON hasil.user_id=users.user_id ";
					break;
			}
		}
		elseif ($_SESSION['is_adminsekolah'])
		{
			switch ($filter) 
			{
				case "kelas" : 
					$qry="SELECT users.username, users.real_name, kelas.nm_kelas, ujian.nm_ujian, hasil.benar, hasil.soal, hasil.nilai, hasil.tgl_test, hasil.kd_hasil, users.user_id, hasil.tgl_selesai-hasil.tgl_test as selisih, users.user_id FROM hasil, users, ujian, kelas WHERE   users.kode_sekolah='$_SESSION[is_nm_sekolah]' and hasil.user_id=users.user_id and ujian.kd_ujian=hasil.kd_ujian and kelas.kd_kelas=users.kd_kelas and users.kd_kelas='$value' ";//and hasil.status=10 ";
					break;
				case "mapel" : 
					$qry="SELECT users.username, users.real_name, kelas.nm_kelas, ujian.nm_ujian, hasil.benar, hasil.soal, hasil.nilai, hasil.tgl_test, hasil.kd_hasil, users.user_id, hasil.tgl_selesai-hasil.tgl_test as selisih, users.user_id FROM hasil, users, ujian, kelas WHERE  users.kode_sekolah='$_SESSION[is_nm_sekolah]' and hasil.user_id=users.user_id and ujian.kd_ujian=hasil.kd_ujian and kelas.kd_kelas=users.kd_kelas and ujian.kd_ujian='$value' ";//and hasil.status=10 ";
					break;
				case "modul" : 
					$qry="SELECT users.username, users.real_name, kelas.nm_kelas, ujian.nm_ujian, hasil.benar, hasil.soal, hasil.nilai, hasil.tgl_test, hasil.kd_hasil, users.user_id, hasil.tgl_selesai-hasil.tgl_test as selisih, users.user_id FROM hasil, users, ujian, kelas, modul WHERE users.kode_sekolah='$_SESSION[is_nm_sekolah]' and modul.kd_modul=ujian.kd_modul and hasil.user_id=users.user_id and ujian.kd_ujian=hasil.kd_ujian and kelas.kd_kelas=users.kd_kelas and ujian.kd_modul='$value' ";//and hasil.status=10 ";
					break;
				case "periode" : 
					$patokan1=$a[3]." 00:00:00";
					$patokan2=$a[4]." 23:59:59";
					$qry="SELECT users.username, users.real_name, kelas.nm_kelas, ujian.nm_ujian, hasil.benar, hasil.soal, hasil.nilai, hasil.tgl_test, hasil.kd_hasil, users.user_id, hasil.tgl_selesai, hasil.tgl_selesai-hasil.tgl_test as selisih, users.user_id FROM hasil, users, ujian, kelas WHERE  users.kode_sekolah='$_SESSION[is_nm_sekolah]' and hasil.user_id=users.user_id and ujian.kd_ujian=hasil.kd_ujian and kelas.kd_kelas=users.kd_kelas and hasil.tgl_test < '$patokan2' and hasil.tgl_test > '$patokan1' ";//and hasil.status=10 ";
					break;
				default : 
					$qry="SELECT users.username, users.real_name, kelas.nm_kelas, ujian.nm_ujian, hasil.benar, hasil.soal, hasil.nilai, hasil.tgl_test, hasil.kd_hasil, users.user_id, hasil.tgl_selesai-hasil.tgl_test as selisih, users.user_id FROM hasil, users, ujian, kelas WHERE  users.kode_sekolah='$_SESSION[is_nm_sekolah]' and hasil.user_id=users.user_id and ujian.kd_ujian=hasil.kd_ujian and kelas.kd_kelas=users.kd_kelas ";//and hasil.status=10 ";
					break;
			}
		}		
		//echo $qry;
		$query=mysql_query($qry);
		while ($dt=mysql_fetch_array($query))
		{		
			$kd=$converter->encode($dt[kd_hasil]);
			if (!empty($dt[tgl_test])) $tgl=date("d-m-Y H:i", $dt[tgl_test]);		
			else $tgl='-';		
			$selisih='';			
			$selisih1=$dt[selisih];
			if (floor($selisih1/86400)>=1)		
			{	
				$selisih=floor($selisih1/86400)." Hari ";
				$selisih1=$selisih1-($selisih*86400);
			}
			if (floor($selisih1/3600)>=1)		
			{	
				$selisih.=floor($selisih1/3600)." Jam ";
				$selisih1=$selisih1-($selisih*3600);
			}
			if (floor($selisih1/60)>=1)	$selisih.=floor($selisih1/60)." Menit ";
			//if ($selisih1%60!=0) 		$selisih.=($selisih1%60)." Detik";
			$i++;
  ?>  
				
				<tr>
					<td align="center"><?= $i ?>. </td>
					<td align="center">
<a href="./?ac=badresult&del=<?= "$kd&filter=$_GET[filter]&value=$_GET[value]" ?>"><i class="fa fa-trash"></i></a> |
<a href="#" onclick="window.open('<?= "$namaserver/ujian_new/view_result.php?id=$kd"; ?>', '_blank');"><i class="fa fa-search"></i></a> | 						
<a href="./?ac=loop&loop=<?= "$kd&filter=$_GET[filter]&value=$_GET[value]" ?>"><i class="fa fa-history"></i></a>
						
					</td>
					<td align="left"><?= $dt[username]; ?></td>
					<td><?= $dt[real_name]; ?></td>
					<td><?= $dt[nm_kelas]; ?></td>
					<td><?= $dt[nm_ujian]; ?></td>
					<td><?= $dt[benar] ?></td>
					<td><?= $dt[soal] ?></td>
					<td><?= $dt[nilai] ?></td>
					<td><?= date('d-m-Y H:i', $dt[tgl_test]); ?></td>
					<td><?= $selisih; ?></td>
				</tr>
				<?php } ?>
			</tbody>
		</table>
	</div>
	<!-- /.box-body -->
</div>
<script>
    $(document).ready(function() {
        $('#example1').dataTable({
            "aLengthMenu": [
                [50, 100, 250, 500, -1],
                [50, 100, 200, 500, "All"]
            ],
            "iDisplayLength": 100
        });
    });

</script>