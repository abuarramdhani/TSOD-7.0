<?Php
	header ("Location: ../");
?>